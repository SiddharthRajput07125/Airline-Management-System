package project;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

class FileOperation{
    static void fileWrite(Passenger p) throws IOException, SQLException{
        File f=new File("I://"+p.passengerName);
        FileWriter fw=new FileWriter(f);
        fw.write("Passenger Name:"+p.passengerName+"\n");
        fw.write("Flight Number:"+p.flight_Number+"\n");
        fw.write("Cabin Type:"+p.cabinType+"\n");
        fw.write("Mobile Number:"+p.mobileNumber+"\n");
        fw.write("Age:"+p.age+"\n");
        fw.write("User Id:"+p.userID+"\n");
        fw.write("Total Price:"+p.totalPrice);
        fw.flush();
        fw.close();
        DataBase.passengerConnection(p,f);
    }
}