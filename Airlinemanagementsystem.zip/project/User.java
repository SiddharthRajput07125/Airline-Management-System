package project;
import java.util.HashMap;

public class User{
    static HashMap<String,String> user=new HashMap<>();
}