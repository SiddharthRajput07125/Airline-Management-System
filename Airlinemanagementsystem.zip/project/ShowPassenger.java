package project;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ShowPassenger extends JFrame{
    static String[] columns = {"PassengerName", "UserId",  "Flight Number", "Cabin Type", "Mobile Number", "Total Price", "Age"};
    DefaultTableModel model = new DefaultTableModel(columns, 0);
    private JButton back;
    ShowPassenger(){
        setTitle("Passengers Details");
        setSize(1020, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(20, 20));


        JPanel header = new JPanel();
        JLabel headerLabel = new JLabel("Showing Passengers Details", JLabel.CENTER);
        headerLabel.setFont(new Font("Serif", Font.BOLD, 30));
        headerLabel.setForeground(Color.WHITE);
        header.setBackground(new Color(0, 102, 204));
        header.setPreferredSize(new Dimension(getWidth(), 80));
        header.add(headerLabel);
        add(header, BorderLayout.NORTH);

        if (Passenger.parr.isEmpty()) {
            JLabel noFlightsLabel = new JLabel("No Passenger Till Now", JLabel.CENTER);
            noFlightsLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
            noFlightsLabel.setForeground(Color.RED);
            add(noFlightsLabel, BorderLayout.CENTER);
        } else {
            JTable table = new JTable(model);
            table.setRowHeight(30);
            table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 16));
            table.setFont(new Font("SansSerif", Font.PLAIN, 14));

            LinkedList<String> dummy=sortPassengers();
            for (String key :dummy){
                Passenger passenger = Passenger.parr.get(key);
                Object[] rowData = {
                    passenger.getPassengerName(),
                    passenger.getUserID(),
                    passenger.getFlight_Number(),
                    passenger.getCabinType(),
                    passenger.getMobileNumber(),
                    passenger.getTotalPrice(),
                    passenger.getAge()
                };
                model.addRow(rowData);
            }
           JScrollPane scrollPane = new JScrollPane(table);
           scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
           add(scrollPane, BorderLayout.CENTER);
           }
        
        JPanel footer = new JPanel();
        footer.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        footer.setBackground(new Color(0, 102, 204));

        back = new JButton("Show Previous Slide");
        back.setFont(new Font("SansSerif", Font.BOLD, 18));
        back.setForeground(Color.WHITE);
        back.setBackground(new Color(0, 51, 153));
        back.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        footer.add(back);
        add(footer, BorderLayout.SOUTH);

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Option page");
                new AdminDashboard();
                dispose();
            }
        });
        setVisible(true);
   }
    static LinkedList sortPassengers(){
     LinkedList<String> key=new LinkedList<>(Passenger.parr.keySet());

        for (int i = 0; i < key.size() - 1; i++) {
            for (int j = 0; j < key.size() - i - 1; j++) {
                if (key.get(j).compareTo(key.get(j + 1)) > 0) {
                    // Swap keys[j] and keys[j+1]
                    String temp = key.get(j);
                    key.set(j, key.get(j + 1));
                    key.set(j + 1, temp);
                }
            }
        }
        return key;
   }
}
