package project;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MainPage extends JFrame implements ActionListener {
    private JButton startButton;

    public MainPage() {
        setTitle("Airline Reservation System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600,1400);
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(Color.black);
        JLabel headerLabel = new JLabel("Welcome To Airline Reservation System");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 50));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        headerPanel.setPreferredSize(new Dimension(200, 150));

        JPanel photoPanel = new JPanel();
        photoPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        ImageIcon imageIcon = new ImageIcon("I:\\Sem2\\Project\\airline\\src\\main\\java\\project\\download.jpg");
        JLabel photoLabel = new JLabel(imageIcon);
        photoPanel.add(photoLabel);
        photoPanel.setBackground(Color.black);


        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        startButton = new JButton("Start Booking");
        startButton.setFont(new Font("Arial", Font.BOLD, 24));
        startButton.setForeground(Color.WHITE);
        startButton.setBackground(new Color(0, 153, 255)); 
        startButton.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        buttonPanel.setBackground(Color.black);
        buttonPanel.add(startButton);


        add(headerPanel, BorderLayout.NORTH);
        add(photoPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        startButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            dispose();
            JOptionPane.showMessageDialog(null, "Welcome to the Booking System!");
            new Detail();
        }
    }
    public static void main(String[] args) {
        new MainPage();
    }
}
