package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboard extends JFrame implements ActionListener {

    JButton btnAddFlight, btnShowFlight, btnCheckPassenger, btnPayment,btnExit,mainBtn;
    JLabel headingLabel;

    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(Color.LIGHT_GRAY);

        headingLabel = new JLabel("Admin Panel", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Color.LIGHT_GRAY);

        btnAddFlight = new JButton("Add Flight");
        btnShowFlight = new JButton("Show Flight");
        btnCheckPassenger = new JButton("Check Passenger");
        btnPayment = new JButton("Payment");
        mainBtn=new JButton("Main Page");
        btnExit=new JButton("Exiting");

        btnAddFlight.addActionListener(this);
        btnShowFlight.addActionListener(this);
        btnCheckPassenger.addActionListener(this);
        btnPayment.addActionListener(this);
        btnExit.addActionListener(this);
        mainBtn.addActionListener(this);

        buttonPanel.add(btnAddFlight);
        buttonPanel.add(btnShowFlight);
        buttonPanel.add(btnCheckPassenger);
        buttonPanel.add(btnPayment);
        buttonPanel.add(mainBtn);
        buttonPanel.add(btnExit);

        mainPanel.add(headingLabel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAddFlight) {
            JOptionPane.showMessageDialog(this, "Add Flight selected");
            new AddFlight();
            dispose();
        } else if (e.getSource() == btnShowFlight) {
            JOptionPane.showMessageDialog(this, "Show Flight selected");
            new FlightDisplay();
            dispose();
        } else if (e.getSource() == btnCheckPassenger) {
            JOptionPane.showMessageDialog(this, "Check Passenger selected");
            new ShowPassenger();
            dispose();
        } else if (e.getSource() == btnPayment) {
            JOptionPane.showMessageDialog(this, "Payment selected");
            new Payment();
            dispose();
        }
        else if(e.getSource()==mainBtn){
            JOptionPane.showMessageDialog(null,"Opening Main Page");
            new MainPage();
            dispose();
        }
        else if(e.getSource()==btnExit){
            JOptionPane.showMessageDialog(this,"Exiting");
            dispose();
        }
    }
}
