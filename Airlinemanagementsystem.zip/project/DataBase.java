package project;

import java.io.*;
import java.sql.*;

class DataBase{
    static Connection connectionForDataBase() throws SQLException{
        String dburl="jdbc:postgresql://aws-0-ap-south-1.pooler.supabase.com:6543/postgres";
        String dbuser="postgres.qqwbqtiikyybjebhkycd";
        String dbpass="Jh8zeEvDJSRa9Roe";
        Connection con=DriverManager.getConnection(dburl, dbuser, dbpass);
        return con;
    }

    static void setConnection(Flight f) throws SQLException {
        String sql="Insert into flights values(?,?,?,?,?,?,?,?)";
        PreparedStatement pst=connectionForDataBase().prepareStatement(sql);
        pst.setString(1, f.origin);
        pst.setString(2, f.destination);
        pst.setString(3, f.flightName);
        pst.setString(4, f.flightNumber);
        pst.setString(5, f.flightTime);
        pst.setInt(6, f.economyTicketPrice);
        pst.setInt(7, f.businessTicketPrice);
        pst.setInt(8, f.availableSeat);
        pst.executeUpdate();
        pst.close();
        connectionForDataBase().close(); 
    }

    static void passengerConnection(Passenger passenger, File f) throws SQLException, FileNotFoundException{
        String sql="Insert into passengers(passenger_name,userid,age,flight_number,cabin_type,mobile_number,total_price,file_data) values(?,?,?,?,?,?,?,?)";
        PreparedStatement pst=connectionForDataBase().prepareStatement(sql);
        pst.setString(2, passenger.userID);
        pst.setString(1, passenger.passengerName);
        pst.setInt(3, passenger.age);
        pst.setString(4, passenger.flight_Number);
        pst.setString(5, passenger.cabinType);
        pst.setString(6, passenger.mobileNumber);
        pst.setInt(7, passenger.totalPrice);
        InputStream fr=new FileInputStream(f);
        pst.setBinaryStream(8, fr);
        pst.executeUpdate();
    }
    static void passengerDeletion(Passenger p2) throws SQLException{
        String sql="Delete from passengers where userid=?";
        PreparedStatement pst=connectionForDataBase().prepareStatement(sql);
        pst.setString(1, p2.userID);
        pst.executeUpdate();
    }
    static void seatUpdate(int i) throws SQLException{
        String sql="Update flights set availableseats=? where flight_number=?";
        PreparedStatement pst=connectionForDataBase().prepareStatement(sql);
        pst.setInt(1, Flight.farr.get(i).availableSeat);
        pst.setString(2, Flight.farr.get(i).flightNumber);
        pst.executeUpdate();
    }
    static void loginConnection(String email,String password) throws SQLException{
       String sql="{call login(?,?)}"; 
       CallableStatement cst=connectionForDataBase().prepareCall(sql);
       cst.setString(1,email);
       cst.setString(2, password);
       cst.executeUpdate();
    }
}
