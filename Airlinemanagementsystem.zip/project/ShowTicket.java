package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ShowTicket extends JFrame {
    private JTextField nameField;
    private JTextField userIdField;
    private JPanel ticketPanel;
    JButton previous;

    ShowTicket() {
        setTitle("Showing Ticket");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        inputPanel.setBackground(new Color(245, 245, 245));

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        nameField = new JTextField();
        nameField.setFont(new Font("Arial", Font.PLAIN, 16));

        JLabel userIdLabel = new JLabel("User ID:");
        userIdLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        userIdField = new JTextField();
        userIdField.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton submitButton = createButton("Show Ticket", new Color(0, 102, 204), Color.WHITE);
        previous = createButton("Previous Slide", new Color(255, 69, 0), Color.WHITE);

        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(userIdLabel);
        inputPanel.add(userIdField);
        inputPanel.add(submitButton);
        inputPanel.add(previous);

        add(inputPanel, BorderLayout.NORTH);

        ticketPanel = new JPanel();
        ticketPanel.setLayout(new BorderLayout());
        ticketPanel.setBackground(new Color(255, 255, 255));
        ticketPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
        ticketPanel.setVisible(false);

        add(ticketPanel, BorderLayout.CENTER);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String userId = userIdField.getText();
                if (Passenger.parr.containsKey(userId)) {
                    Passenger p1 = Passenger.parr.get(userId);
                    showTicket(p1);
                } else {
                    JOptionPane.showMessageDialog(null, "User ID not found");
                    nameField.setText("");
                    userIdField.setText("");
                }
            }
        });

        previous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UserChoice();
                dispose();
            }
        });

        setVisible(true);
    }

    private JButton createButton(String text, Color backgroundColor, Color textColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(textColor);
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    void showTicket(Passenger p) {
        ticketPanel.removeAll();

        JLabel ticketLabel = new JLabel(
            "<html><h2 style='color: #0d6efd;'>Ticket Details</h2><br>" +
            "<b>Name:</b> " + p.passengerName + "<br>" +
            "<b>User ID:</b> " + p.userID + "<br>" +
            "<b>Flight Number:</b> " + p.flight_Number + "<br>" +
            "<b>Price:</b> $" + p.totalPrice + "<br>" +
            "<b>Cabin Type:</b> " + p.cabinType + "<br>" +
            "<b>Mobile Number:</b> " + p.mobileNumber + "</html>",
            SwingConstants.CENTER
        );
        ticketLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        ticketLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        ticketPanel.add(ticketLabel, BorderLayout.CENTER);
        ticketPanel.setVisible(true);

        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        new ShowTicket();
    }
}
