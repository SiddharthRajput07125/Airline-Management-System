package project;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;

class Flight extends JFrame{
    static Scanner sc=new Scanner(System.in);
    String origin,destination,flightName,flightNumber,flightTime;
    int economyTicketPrice, businessTicketPrice,availableSeat;
    static ArrayList<Flight> farr=new ArrayList<>();
    public Flight(String origin, String destination, String flightName, String flightNumber, String flightTime, int economyTicketPrice, int businessTicketPrice, int availableSeat){
        this.origin=origin;
        this.destination=destination;
        this.flightName=flightName;
        this.flightNumber=flightNumber;
        this.flightTime=flightTime;
        this.economyTicketPrice=economyTicketPrice;
        this.businessTicketPrice=businessTicketPrice;
        this.availableSeat=availableSeat;
    }
    public String getOrigin() {
        return origin;
    }
    public String getDestination() {
        return destination;
    }
    public String getFlightName() {
        return flightName;
    }
    public String getFlightNumber() {
        return flightNumber;
    }
    public String getFlightTime() {
        return flightTime;
    }
    public int getEconomyTicketPrice() {
        return economyTicketPrice;
    }
    public int getBusinessTicketPrice() {
        return businessTicketPrice;
    }
    public int getAvailableSeat() {
        return availableSeat;
    }
    static int bookSeat(int index){
        if(Flight.farr.get(index).getAvailableSeat()<1){
            return 0;
        }
        else{
            Flight.farr.get(index).availableSeat--;
            return 1;
        }
    }
}
