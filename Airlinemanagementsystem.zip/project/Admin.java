package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Admin extends JFrame implements ActionListener{
    static final int frameWidth = 1020, frameHeight = 650;
    JPanel mainPanel;
    JLabel warningLabel, passwordWarner;
    static JTextField emailTxtF;
    JPasswordField passwordTxtF;
    JButton signInBtn;
    String adminEmail="kavya@gmail.com";
    String adminPassword="hellobye";

    Admin(){
        heading();
        mainFrame();
        initFrame();
    }
    protected void initFrame() {
        this.setTitle("Admin Login Page");
        this.setSize(frameWidth, frameHeight);
        this.setResizable(false);
        this.setLayout(null); 
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(new Color(34, 34, 34));
        this.add(mainPanel);
        this.setVisible(true);
    }
    void mainFrame(){
        mainPanel = new JPanel();
        mainPanel.setBounds(300, 100, frameWidth - 600, 400);
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(45, 45, 45));
        mainPanel.setBorder(javax.swing.BorderFactory.createLineBorder(Color.white, 2));

        setEmailPanel();
        setPasswordPanel();
        setButtons();
        initWarningLabel();
    }
    protected void heading(){
        JPanel header=new JPanel();
        header.setBackground(new Color(34,34,34));
        header.setBounds(300,10,frameWidth-600,50);
        JLabel heading=new JLabel("Admin Login Details");
        heading.setFont(new Font("Arial",Font.BOLD,20));
        heading.setForeground(Color.white);
        heading.setBounds(300, 10, 120, 50);
        header.add(heading);
        this.add(header);
    }

    protected void setEmailPanel() {
        JLabel emailString = new JLabel();
        emailString.setText("Email:");
        emailString.setBounds(50, 50, 120, 30);
        emailString.setFont(new Font("Arial", Font.BOLD, 18));
        emailString.setForeground(Color.LIGHT_GRAY);
        mainPanel.add(emailString);

        emailTxtF = new JTextField();
        emailTxtF.setBounds(50, 90, 300, 40);
        emailTxtF.setMargin(new Insets(5, 10, 5, 10));
        emailTxtF.setFont(new Font("Arial", Font.PLAIN, 16));
        emailTxtF.setForeground(Color.WHITE);
        emailTxtF.setCaretColor(Color.GREEN);
        emailTxtF.setBackground(new Color(60, 60, 60));
        mainPanel.add(emailTxtF);
    }

    protected void setPasswordPanel() {
        JLabel passString = new JLabel();
        passString.setText("Password:");
        passString.setBounds(50, 150, 120, 30);
        passString.setFont(new Font("Arial", Font.BOLD, 18));
        passString.setForeground(Color.LIGHT_GRAY);
        mainPanel.add(passString);

        passwordTxtF = new JPasswordField();
        passwordTxtF.setBounds(50, 190, 300, 40);
        passwordTxtF.setMargin(new Insets(5, 10, 5, 10));
        passwordTxtF.setBackground(new Color(60, 60, 60));
        passwordTxtF.setForeground(Color.WHITE);
        passwordTxtF.setCaretColor(Color.GREEN);
        mainPanel.add(passwordTxtF);
    }
    protected void setButtons() {
        signInBtn = new JButton();
        signInBtn.setBounds(140, 260, 130, 40);
        signInBtn.setText("Login");
        signInBtn.setMargin(new Insets(5, 5, 5, 5));
        signInBtn.setFont(new Font("Arial", Font.BOLD, 16));
        signInBtn.setForeground(Color.WHITE);
        signInBtn.setBackground(new Color(34, 139, 34));
        signInBtn.setFocusable(false);
        signInBtn.addActionListener(this);
        mainPanel.add(signInBtn);
    }
    protected void initWarningLabel() {
        warningLabel = new JLabel();
        warningLabel.setBounds(140, 310, 300, 30);
        warningLabel.setFont(new Font("Arial", Font.BOLD, 14));
        warningLabel.setForeground(Color.RED);
        mainPanel.add(warningLabel);

        passwordWarner = new JLabel();
        passwordWarner.setBounds(140, 340, 300, 30);
        passwordWarner.setFont(new Font("Arial", Font.BOLD, 14));
        passwordWarner.setForeground(Color.RED);
        mainPanel.add(passwordWarner);
    }
    
    protected boolean isValidEmailId(String email) {
        if (email.equals(adminEmail)) {
            return true;
        }
        else{
            return false;
        }
    }

    protected boolean isValidPassword(String password) {
        if (password.equals(adminPassword)) {
            return true;
        }
        else{
            return false;
        }
    }

    protected static String getEmailId() {
        return emailTxtF.getText();
    }

    @SuppressWarnings("deprecation")
    protected String getPassword() {
        try {
            return passwordTxtF.getText();
        } catch (NullPointerException e) {
            return "";
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==signInBtn){
            if (!isValidEmailId(getEmailId())) {
                warningLabel.setText("Invalid email id.");
                passwordWarner.setText("");
            } else if (!isValidPassword(getPassword())) {
                warningLabel.setText("Invalid Password.");
            }
            else if(isValidEmailId(getEmailId()) && isValidPassword(getPassword())){
                JOptionPane.showMessageDialog(null, "Opening Admin page");
                new AdminDashboard();
                dispose();
            }
        }
    }
    
}
