package project;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class AddFlight extends JFrame {

    @SuppressWarnings("unused")
    private JTextField originField, destinationField, flightNameField, flightNumberField, flightTimeField, economyTicketPriceField, businessTicketPriceField, availableSeatField;
    private JButton previousButton, submitButton;
    static int i=0;
    public AddFlight() {
        setTitle("Add Flight");
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 1, 10, 10)); 

        Font labelFont = new Font("Arial", Font.BOLD, 20);
        Font textFieldFont = new Font("Arial", Font.PLAIN, 20);
        Dimension panelSize = new Dimension(380, 60);

        JPanel originPanel = createPanelWithLabelAndField("Origin:", labelFont, textFieldFont, panelSize);
        originField = (JTextField) originPanel.getComponent(1);

        JPanel destinationPanel = createPanelWithLabelAndField("Destination:", labelFont, textFieldFont, panelSize);
        destinationField = (JTextField) destinationPanel.getComponent(1);

        JPanel flightNamePanel = createPanelWithLabelAndField("Flight Name:", labelFont, textFieldFont, panelSize);
        flightNameField = (JTextField) flightNamePanel.getComponent(1);

        JPanel flightNumberPanel = createPanelWithLabelAndField("Flight Number:", labelFont, textFieldFont, panelSize);
        flightNumberField = (JTextField) flightNumberPanel.getComponent(1);

        JPanel flightTimePanel = createPanelWithLabelAndField("Flight Time:", labelFont, textFieldFont, panelSize);
        flightTimeField = (JTextField) flightTimePanel.getComponent(1);

        JPanel economyTicketPricePanel = createPanelWithLabelAndField("Economy Price:", labelFont, textFieldFont, panelSize);
        economyTicketPriceField = (JTextField) economyTicketPricePanel.getComponent(1);

        JPanel businessTicketPricePanel = createPanelWithLabelAndField("Business Price:", labelFont, textFieldFont, panelSize);
        businessTicketPriceField = (JTextField) businessTicketPricePanel.getComponent(1);

        JPanel availableSeatPanel = createPanelWithLabelAndField("Available Seat:", labelFont, textFieldFont, panelSize);
        availableSeatField = (JTextField) availableSeatPanel.getComponent(1);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        previousButton = new JButton("Previous Slide");
        submitButton = new JButton("Submit");

        previousButton.setFont(labelFont);
        submitButton.setFont(labelFont);

        buttonPanel.add(previousButton);
        buttonPanel.add(submitButton);
        buttonPanel.setBackground(Color.LIGHT_GRAY);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        buttonPanel.setPreferredSize(panelSize);

        add(originPanel);
        add(destinationPanel);
        add(flightNamePanel);
        add(flightNumberPanel);
        add(flightTimePanel);
        add(economyTicketPricePanel);
        add(businessTicketPricePanel);
        add(availableSeatPanel);
        add(buttonPanel);

        setVisible(true);

        previousButton.addActionListener(e -> {
            new AdminDashboard();
            dispose();
        });

        submitButton.addActionListener(e -> {
            Flight.farr.add(new Flight(originField.getText(), destinationField.getText(), flightNameField.getText(), flightNumberField.getText(), flightTimeField.getText(), Integer.parseInt(economyTicketPriceField.getText()), Integer.parseInt(businessTicketPriceField.getText()), Integer.parseInt(availableSeatField.getText())));
            JOptionPane.showMessageDialog(this,"Flight Added");
            try {
                DataBase.setConnection(Flight.farr.get(i));
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            i++;
            new AdminDashboard();
            dispose();
        });
    }

    private JPanel createPanelWithLabelAndField(String labelText, Font labelFont, Font textFieldFont, Dimension panelSize) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JLabel label = new JLabel(labelText);
        label.setFont(labelFont);
        label.setForeground(Color.white);
        label.setPreferredSize(new Dimension(150, 120));
        JTextField textField = new JTextField(20);
        textField.setFont(textFieldFont);

        panel.add(label, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);

        panel.setBackground(Color.BLACK);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(panelSize);

        return panel;
    }
}
