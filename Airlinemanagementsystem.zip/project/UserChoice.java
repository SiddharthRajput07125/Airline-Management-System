package project;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

class UserChoice extends JFrame implements ActionListener {
    JButton showFlightsButton;
    JButton bookTicketsButton;
    JButton showBookedTicketsButton;
    JButton cancelReservationButton;
    JButton exit;
    JButton mainPage;

    UserChoice() {
       
        setTitle("User Choices");
        setSize(800, 650);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("User List");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 30));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        headerPanel.setPreferredSize(new Dimension(800, 100));
        add(headerPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10));
        buttonPanel.setBackground(Color.black);

        showFlightsButton = createButton("1. Show Flights");
        bookTicketsButton = createButton("2. Book Tickets");
        showBookedTicketsButton = createButton("3. Show Booked Tickets");
        cancelReservationButton = createButton("4. Cancel Reservation");
        mainPage = createButton("5. Main Page");
        exit = createButton("6. Exit");

        buttonPanel.add(showFlightsButton);
        buttonPanel.add(bookTicketsButton);
        buttonPanel.add(showBookedTicketsButton);
        buttonPanel.add(cancelReservationButton);
        buttonPanel.add(mainPage);
        buttonPanel.add(exit);

        add(buttonPanel, BorderLayout.CENTER);

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.black);
        add(footerPanel, BorderLayout.SOUTH);

        showFlightsButton.addActionListener(this);
        bookTicketsButton.addActionListener(this);
        showBookedTicketsButton.addActionListener(this);
        cancelReservationButton.addActionListener(this);
        mainPage.addActionListener(this);
        exit.addActionListener(this);
        this.setVisible(true);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.pink);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setFocusPainted(false);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == showFlightsButton) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "Available Flights Feature will be Implemented here.");
            new FlightDisplay1();
        }
        if (e.getSource() == bookTicketsButton) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "Book Tickets Feature will be Implemented here.");
            new PassengerBooking();
        }
        if (e.getSource() == showBookedTicketsButton) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "Booked Tickets Will Be shown here");
            new ShowTicket();
        }
        if (e.getSource() == cancelReservationButton) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "Cancel The Reservation feature will be Implemented here");
            new CancelReservation1();
        }
        if (e.getSource() == exit) {
            this.dispose();
            JOptionPane.showMessageDialog(null, "Exiting the Airline System");
        }
        if (e.getSource() == mainPage) {
            JOptionPane.showMessageDialog(null, "Opening Main Page");
            dispose();
            new MainPage();
        }
    }
}