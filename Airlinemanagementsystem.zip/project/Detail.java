package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Detail extends JFrame {
    private JRadioButton userRadioButton;
    private JRadioButton adminRadioButton;
    private JButton submitButton;
    private JLabel resultLabel;

    public Detail() {
        setTitle("User or Admin");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setVisible(true);

        JLabel questionLabel = new JLabel("Are you a User or Admin?", SwingConstants.CENTER);
        questionLabel.setPreferredSize(new Dimension(200,100));
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        add(questionLabel, BorderLayout.NORTH);

        userRadioButton = new JRadioButton("User");
        adminRadioButton = new JRadioButton("Admin");

        ButtonGroup group = new ButtonGroup();
        group.add(userRadioButton);
        group.add(adminRadioButton);

        JPanel panel = new JPanel();
        panel.add(userRadioButton);
        panel.add(adminRadioButton);

        add(panel, BorderLayout.CENTER);

        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.BOLD, 20));
        submitButton.setForeground(Color.WHITE);
        submitButton.setBackground(Color.BLUE);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (userRadioButton.isSelected()) {
                    resultLabel.setText("You selected: User");
                    new Login();
                    dispose();
                } else if (adminRadioButton.isSelected()) {
                    resultLabel.setText("You selected: Admin");
                    new Admin();
                    dispose();
                } else {
                    resultLabel.setText("Please select an option.");
                }
            }
        });

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setPreferredSize(new Dimension(100,50));
        resultLabel = new JLabel("", SwingConstants.CENTER);
        bottomPanel.add(submitButton, BorderLayout.NORTH);
        bottomPanel.add(resultLabel, BorderLayout.CENTER);

        add(bottomPanel, BorderLayout.SOUTH);
    }

}
