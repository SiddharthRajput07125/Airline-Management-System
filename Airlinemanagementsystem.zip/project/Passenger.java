package project;
import java.util.Hashtable;
import java.util.Scanner;

import javax.swing.JFrame;

class Passenger extends JFrame{
    static Scanner sc=new Scanner(System.in);
    String passengerName, userID, flight_Number,cabinType,mobileNumber;
    int totalPrice,age;
    static Hashtable<String,Passenger> parr=new Hashtable();
	public String getPassengerName() {
        return passengerName;
    }
    public String getUserID() {
        return userID;
    }
    public String getFlight_Number() {
        return flight_Number;
    }
    public String getCabinType() {
        return cabinType;
    }
    public String getMobileNumber() {
        return mobileNumber;
    }
    public int getTotalPrice() {
        return totalPrice;
    }
    public int getAge() {
        return age;
    }
}