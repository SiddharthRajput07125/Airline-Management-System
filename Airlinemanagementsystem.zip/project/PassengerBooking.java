package project;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

public class PassengerBooking extends JFrame {

    private JTextField nameField, userIdField, flightNumberField, mobileField,agefield;
    private JComboBox<String> cabinTypeComboBox;
    private JButton previousButton, submitButton;
    @SuppressWarnings("unchecked")
    public PassengerBooking() {
        setTitle("Passenger Booking");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 1, 10, 10)); 

        Font labelFont = new Font("Arial", Font.BOLD, 20);
        Dimension panelSize = new Dimension(380, 60);

        // Name Panel
        JPanel namePanel = createPanelWithLabelAndField("Name:", labelFont, panelSize);
        nameField = (JTextField) namePanel.getComponent(1);

        // User ID Panel
        JPanel userIdPanel = createPanelWithLabelAndField("User ID:", labelFont, panelSize);
        userIdField = (JTextField) userIdPanel.getComponent(1);
        Random random = new Random();
        int randomNumber = random.nextInt()/10000;
        if(randomNumber<0){
            randomNumber*=-1;
        }
        userIdField.setText(randomNumber+"");
        userIdField.setEnabled(false);

        // Password Panel
        JPanel agePanel = createPanelWithLabelAndPasswordField("Age", labelFont, panelSize);
        agefield = (JTextField) agePanel.getComponent(1);

        // Cabin Type Panel (with JComboBox)
        JPanel cabinTypePanel = createPanelWithLabelAndComboBox("Cabin Type:", labelFont, panelSize);
        cabinTypeComboBox = (JComboBox<String>) cabinTypePanel.getComponent(1);

        // Flight Number Panel
        JPanel flightNumberPanel = createPanelWithLabelAndField("Flight Number:", labelFont, panelSize);
        flightNumberField = (JTextField) flightNumberPanel.getComponent(1);

        // Mobile Number Panel
        JPanel mobilePanel = createPanelWithLabelAndField("Mobile No:", labelFont, panelSize);
        mobileField = (JTextField) mobilePanel.getComponent(1);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        previousButton = new JButton("Previous Slide");
        submitButton = new JButton("Submit");

        previousButton.setFont(labelFont);
        submitButton.setFont(labelFont);

        buttonPanel.add(previousButton);
        buttonPanel.add(submitButton);
        buttonPanel.setBackground(Color.LIGHT_GRAY);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        buttonPanel.setPreferredSize(panelSize);

        
        add(namePanel);
        add(userIdPanel);
        add(agePanel);
        add(cabinTypePanel);
        add(flightNumberPanel);
        add(mobilePanel);
        add(buttonPanel);

        setVisible(true);

        previousButton.addActionListener(e -> {
            new UserChoice();
            dispose();
        });

        submitButton.addActionListener(e -> {
            try {
                addPassenger();
            } catch (SQLException | IOException e1) {
                e1.printStackTrace();
            }
        });
    }

    private JPanel createPanelWithLabelAndField(String labelText, Font labelFont, Dimension panelSize) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JLabel label = new JLabel(labelText);
        label.setFont(labelFont);
        label.setForeground(Color.white);
        label.setPreferredSize(new Dimension(120,120));
        JTextField textField = new JTextField(20);

        panel.add(label, BorderLayout.WEST);
        panel.add(textField, BorderLayout.CENTER);

        panel.setBackground(Color.PINK);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(panelSize);

        return panel;
    }

    private JPanel createPanelWithLabelAndPasswordField(String labelText, Font labelFont, Dimension panelSize) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.white);
        label.setFont(labelFont);
        label.setPreferredSize(new Dimension(120,120));
        JPasswordField passwordField = new JPasswordField(20);

        panel.add(label, BorderLayout.WEST);
        panel.add(passwordField, BorderLayout.CENTER);

        panel.setBackground(Color.PINK);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(panelSize);

        return panel;
    }

    private JPanel createPanelWithLabelAndComboBox(String labelText, Font labelFont, Dimension panelSize) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.white);
        label.setPreferredSize(new Dimension(120,120));
        label.setFont(labelFont);
        String[] cabinTypes = {"Economy", "Business"};
        JComboBox<String> comboBox = new JComboBox<>(cabinTypes);

        panel.add(label, BorderLayout.WEST);
        panel.add(comboBox, BorderLayout.CENTER);

        panel.setBackground(Color.PINK);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.setPreferredSize(panelSize);

        return panel;
    }

    void addPassenger() throws SQLException, IOException{
        String passengerName = nameField.getText();
        String userID1 = userIdField.getText();
        String flightnumber = flightNumberField.getText();
        String cabinType = cabinTypeComboBox.getSelectedItem()+"";
        String mobileNumber = mobileField.getText();
        int age=Integer.parseInt(agefield.getText());
        boolean flag=true;
        for(int i=0;i<Flight.farr.size();i++){
            if(flightnumber.equals(Flight.farr.get(i).flightNumber)){
                flag=false;
                int n=Flight.bookSeat(i);
                if(n==1){
                    Passenger passenger = new Passenger();
                    passenger.flight_Number=flightnumber;
                    passenger.passengerName=passengerName;
                    passenger.userID=userID1;
                    passenger.cabinType=cabinType;
                    passenger.mobileNumber=mobileNumber;
                    passenger.age=age;
                    if(cabinType.equalsIgnoreCase("Bussiness")){
                        passenger.totalPrice=Flight.farr.get(i).businessTicketPrice;
                    }
                //
                    else{
                        passenger.totalPrice=Flight.farr.get(i).economyTicketPrice;
                    }
                    Passenger.parr.put(userID1, passenger);
                    DataBase.seatUpdate(i);
                    FileOperation.fileWrite(passenger);
                    JOptionPane.showMessageDialog(null,"Ticket Booked");
                    new UserChoice();
                    dispose();
                }
                else{
                    JOptionPane.showMessageDialog(null,"Seat is Not Available");
                }
            }
        }
        if(flag){
            JOptionPane.showMessageDialog(null,"Enter valid Flight Number");
            flightNumberField.setText("");
        }
    }
}

