package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends JFrame implements ActionListener{

    protected static final int frameWidth = 1020, frameHeight = 650;

    static ImageIcon loginFrameLogo = new ImageIcon("solitare.jpg");
    ImageIcon solitaireLogo = new ImageIcon("solitare.jpg");

    JPanel mainPanel;
    JLabel warningLabel, passwordWarner;
    static JTextField emailTxtF;
    JPasswordField passwordTxtF;
    JButton signUpBtn, signInBtn;

    private final String EMAIL_PATTERN = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
    private final Pattern emailPattern = Pattern.compile(EMAIL_PATTERN);

    private final String PASSWORD_PATTERN = "^[\\S]{5,}$";
    private final Pattern passwordPattern = Pattern.compile(PASSWORD_PATTERN);

    
    Login() {
        initMainPanel();
        heading();
        initFrame();
    }
    
    protected void initFrame() {
        this.setTitle("Login Page");
        this.setIconImage(loginFrameLogo.getImage());
        this.setSize(frameWidth, frameHeight);
        this.setResizable(false);
        this.setLayout(null); 
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(new Color(34, 34, 34));
        this.add(mainPanel);
        this.setVisible(true);
    }
    protected void heading(){
        JPanel header=new JPanel();
        header.setBackground(new Color(34,34,34));
        header.setBounds(300,10,frameWidth-600,50);
        JLabel heading=new JLabel("User Login Details");
        heading.setFont(new Font("Arial",Font.BOLD,20));
        heading.setForeground(Color.white);
        heading.setBounds(300, 10, 120, 50);
        header.add(heading);
        this.add(header);
    }

    protected void initMainPanel() {
        mainPanel = new JPanel();
        mainPanel.setBounds(300, 100, frameWidth - 600, 400);
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(45, 45, 45));
        mainPanel.setBorder(javax.swing.BorderFactory.createLineBorder(Color.white, 2));

        setEmailPanel();
        setPasswordPanel();
        setButtons();
        initWarningLabel();
    }

    protected void setEmailPanel() {
        JLabel emailString = new JLabel();
        emailString.setText("Email:");
        emailString.setBounds(50, 50, 120, 30);
        emailString.setFont(new Font("Arial", Font.BOLD, 18));
        emailString.setForeground(Color.LIGHT_GRAY);
        mainPanel.add(emailString);

        emailTxtF = new JTextField();
        emailTxtF.setBounds(50, 90, 300, 40);
        emailTxtF.setMargin(new Insets(5, 10, 5, 10));
        emailTxtF.setFont(new Font("Arial", Font.PLAIN, 16));
        emailTxtF.setForeground(Color.WHITE);
        emailTxtF.setCaretColor(Color.GREEN);
        emailTxtF.setBackground(new Color(60, 60, 60));
        mainPanel.add(emailTxtF);
    }

    protected void setPasswordPanel() {
        JLabel passString = new JLabel();
        passString.setText("Password:");
        passString.setBounds(50, 150, 120, 30);
        passString.setFont(new Font("Arial", Font.BOLD, 18));
        passString.setForeground(Color.LIGHT_GRAY);
        mainPanel.add(passString);

        passwordTxtF = new JPasswordField();
        passwordTxtF.setBounds(50, 190, 300, 40);
        passwordTxtF.setMargin(new Insets(5, 10, 5, 10));
        passwordTxtF.setBackground(new Color(60, 60, 60));
        passwordTxtF.setForeground(Color.WHITE);
        passwordTxtF.setCaretColor(Color.GREEN);
        mainPanel.add(passwordTxtF);
    }

    protected void setButtons() {
        signUpBtn = new JButton();
        signUpBtn.setBounds(50, 260, 130, 40);
        signUpBtn.setText("Register");
        signUpBtn.setMargin(new Insets(5, 5, 5, 5));
        signUpBtn.setFont(new Font("Arial", Font.BOLD, 16));
        signUpBtn.setForeground(Color.WHITE);
        signUpBtn.setBackground(new Color(70, 130, 180));
        signUpBtn.setFocusable(false);
        signUpBtn.addActionListener(this);
        mainPanel.add(signUpBtn);

        signInBtn = new JButton();
        signInBtn.setBounds(220, 260, 130, 40);
        signInBtn.setText("Login");
        signInBtn.setMargin(new Insets(5, 5, 5, 5));
        signInBtn.setFont(new Font("Arial", Font.BOLD, 16));
        signInBtn.setForeground(Color.WHITE);
        signInBtn.setBackground(new Color(34, 139, 34));
        signInBtn.setFocusable(false);
        signInBtn.addActionListener(this);
        mainPanel.add(signInBtn);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==signUpBtn){
            if(isValidEmailId(getEmailId()) && isValidPassword(getPassword())){
                // System.out.println("hj");
                if(User.user.containsKey(getEmailId())){
                    // System.out.println("hkhk");
                    warningLabel.setText("You are Already a user, please sign in.");
                    passwordWarner.setText("");
                }
                else{
                    try{
                        System.out.println("jhdvj");
                        DataBase.loginConnection(getEmailId(),getPassword());
                        JOptionPane.showMessageDialog(null, "Succesfully registered");
                        User.user.put(getEmailId(),getPassword());
                        new UserChoice();
                        this.dispose();
                    }
                    catch(Exception e1){
                        e1.getStackTrace();
                    }
                }
            }
        }
        if (!isValidEmailId(getEmailId())) {
            warningLabel.setText("Invalid email id.");
            passwordWarner.setText("");
        } else if (!isValidPassword(getPassword())) {
            warningLabel.setText("Invalid Password.");
            passwordWarner.setText("More than 4 chars & no spacing.");
        }
        else if(e.getSource()==signInBtn){
            if(User.user.containsKey(getEmailId()) && User.user.get(getEmailId()).equals(getPassword())){
                new UserChoice();
                this.dispose();
            }
            else{
                passwordWarner.setText("");
                warningLabel.setText("Invalid email_id OR Password.");
            }
        }
    }

    protected void initWarningLabel() {
        warningLabel = new JLabel();
        warningLabel.setBounds(50, 310, 300, 30);
        warningLabel.setFont(new Font("Arial", Font.BOLD, 14));
        warningLabel.setForeground(Color.RED);
        mainPanel.add(warningLabel);

        passwordWarner = new JLabel();
        passwordWarner.setBounds(50, 340, 300, 30);
        passwordWarner.setFont(new Font("Arial", Font.BOLD, 14));
        passwordWarner.setForeground(Color.RED);
        mainPanel.add(passwordWarner);
    }

    protected boolean isValidEmailId(String email) {
        if (email == null) {
            return false;
        }
        Matcher matcher = emailPattern.matcher(email);
        return matcher.matches();
    }

    protected boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        Matcher matcher = passwordPattern.matcher(password);
        return matcher.matches();
    }

    protected static String getEmailId() {
        return emailTxtF.getText();
    }

    @SuppressWarnings("deprecation")
    protected String getPassword() {
        try {
            return passwordTxtF.getText();
        } catch (NullPointerException e) {
            return "";
        }
    }
}
